Wetrix N64 Recomp - bundled HD Textures

Included with Wetrix Recompiled 0.1.1 on every platform. No separate download
or installation is required. Keep Textures/hd-sprites beside the Wetrix
application; its manifest is Textures/hd-sprites/rt64.json.
Restart the game after adding or removing the pack.

Graphics > HD Textures controls the whole pack and defaults to On.
Off restores the native textures. Removing Textures/hd-sprites hides the
option on the next launch. A saved Off preference is remembered.

This preview pack contains AI-assisted redraws of the English menu sprites,
digits and static interface sprites, plus 92 paired font textures. It also
includes all 63 animated main-menu piece icons and visible gameplay sprites:
arrows, water orbs and splashes, fireballs, bombs and explosions, ice, ducks,
rocks, debris, colored orbs, sparks, rings, spikes, arches and gems.
Seven main-menu carousel labels are individually redrawn with their original
custom font at 16x native resolution for 4K, with cleaned transparent edges.
The idle/demo Wetrix plaque uses a new 16x redraw. The clock's ten states and
the English earthquake meter's gray/colored fill variants are included.
The GAME DESIGN STUDIO subtitle under ZED TWO also uses a 16x redraw.
All ten red digital lesson/timer digits have cleaned 16x redraws.
Original frame order, animation timing, transparency and placement are kept.
The copyright text continues using the game's original letter animation.

Experimental land detail: terrain/land-detail.png adds subtle neutral surface
grain and faint grids with two different spacings over the native colored
checker polygons. Original geometry, lighting and colors remain. To remove
this preview, move that PNG outside the pack
and restart. HD Textures Off also disables it along with all other HD art.

Known coverage limits: font glyph 52 retains native artwork pending quality
review. Non-English menu variants
retain their original art. Three intentionally invisible/blinking billboard
texture hashes remain native. Some context-dependent texture uploads may
also fall back to native art. Backgrounds and other 3D materials are not remastered.
The pack is a preview; it is not a complete replacement of every 2D texture.

No ROM, executable, save data or original texture captures are included.
